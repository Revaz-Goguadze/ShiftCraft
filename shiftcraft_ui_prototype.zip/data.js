// Sample data for the prototype (no backend)
const Data = (() => {
  const users = [
    { id: 'u1', name: 'Alice Brown', role: 'STAFF', skills:['Nurse'] },
    { id: 'u2', name: 'Bob Chen', role: 'STAFF', skills:['Nurse'] },
    { id: 'u3', name: 'Dana Roy', role: 'STAFF', skills:['Lab'] },
    { id: 'm1', name: 'Maria Gomez', role: 'MANAGER', skills:['Admin'] },
  ];
  const templates = [
    { id:'t1', name:'Day Shift', role:'STAFF', start:'08:00', end:'16:00' },
    { id:'t2', name:'Evening Shift', role:'STAFF', start:'16:00', end:'00:00' },
  ];
  // Pre-seed some shifts for current week (Mon-Sun)
  function getMonday(d=new Date()) {
    const date = new Date(d);
    const day = (date.getDay()+6)%7; // 0 Monday
    date.setDate(date.getDate()-day);
    date.setHours(0,0,0,0);
    return date;
  }
  const monday = getMonday();
  const shifts = [];
  const fmt = (date)=>date.toISOString().slice(0,10);
  for(let i=0;i<7;i++){
    const d = new Date(monday); d.setDate(d.getDate()+i);
    shifts.push({ id:`s${i+1}`, templateId:'t1', date:fmt(d), assigneeId: i%2===0?'u1':'u2', status:'PUBLISHED' });
  }
  // Requests and approvals store in memory
  const leaveRequests = [];
  const swaps = [];
  return { users, templates, shifts, leaveRequests, swaps, getMonday, fmt };
})();
