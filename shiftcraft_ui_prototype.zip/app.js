// Lightweight SPA controller
const state = {
  role: localStorage.getItem('role') || null,
  weekStart: null,
};

// DOM helpers
const $ = (sel,root=document)=>root.querySelector(sel);
const $$ = (sel,root=document)=>Array.from(root.querySelectorAll(sel));

// Init
window.addEventListener('DOMContentLoaded', () => {
  // wire nav
  $$('.nav-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>showPage(btn.dataset.target));
  });
  $('#switchRoleBtn').addEventListener('click', ()=>chooseRole(true));

  // schedule controls
  $('#prevWeek').addEventListener('click', ()=>{ shiftWeek(-7); renderSchedule(); });
  $('#nextWeek').addEventListener('click', ()=>{ shiftWeek(7); renderSchedule(); });

  // forms
  $('#leaveForm').addEventListener('submit', onLeaveSubmit);
  $('#templateForm').addEventListener('submit', onTemplateSubmit);
  $('#timesheetForm').addEventListener('submit', onTimesheetGenerate);

  // initial role
  if(!state.role){ chooseRole(false); } else { applyRole(); }

  // default route
  showPage('schedule');
});

function chooseRole(allowClose){
  const modal = $('#roleModal');
  modal.style.display='flex';
  $$('.role-choices button', modal).forEach(b=>{
    b.onclick = ()=>{
      state.role = b.dataset.role;
      localStorage.setItem('role', state.role);
      modal.style.display='none';
      applyRole();
    };
  });
  if(allowClose){
    modal.addEventListener('click', (e)=>{ if(e.target===modal) modal.style.display='none'; }, { once:true });
  }
}

function applyRole(){
  $('#roleLabel').textContent = state.role==='MANAGER' ? 'Manager' : 'Staff';
  // Manager-only panels
  $$('.manager-only').forEach(el=> el.classList.toggle('hidden', state.role!=='MANAGER'));
  // prefill dates
  const today = new Date();
  $('input[name=start]', $('#leaveForm')).value = Data.fmt(today);
  const end = new Date(today); end.setDate(today.getDate()+1);
  $('input[name=end]', $('#leaveForm')).value = Data.fmt(end);
  state.weekStart = Data.getMonday();
  renderSchedule();
  renderTemplates();
  renderRequests();
}

function showPage(name){
  $$('.nav-btn').forEach(b=> b.classList.toggle('active', b.dataset.target===name));
  $$('.page').forEach(p=> p.classList.add('hidden'));
  $(`#page-${name}`).classList.remove('hidden');
}

function shiftWeek(days){
  const d = new Date(state.weekStart);
  d.setDate(d.getDate()+days);
  state.weekStart = d;
}

// ----- Schedule -----
function renderSchedule(){
  const weekLabel = $('#weekLabel');
  const start = new Date(state.weekStart);
  const end = new Date(start); end.setDate(end.getDate()+6);
  weekLabel.textContent = `${start.toDateString()} – ${end.toDateString()}`;

  const grid = $('#scheduleGrid');
  grid.innerHTML='';
  // header row
  const head = document.createElement('div'); head.className='cell head'; head.textContent='Staff';
  grid.appendChild(head);
  for(let i=0;i<7;i++){
    const d = new Date(start); d.setDate(d.getDate()+i);
    const hd = document.createElement('div'); hd.className='cell head'; hd.textContent = d.toLocaleDateString(undefined,{weekday:'short', month:'short', day:'numeric'});
    grid.appendChild(hd);
  }
  const staff = Data.users.filter(u=>u.role==='STAFF');
  staff.forEach(u=>{
    const nameCell = document.createElement('div'); nameCell.className='cell head';
    nameCell.innerHTML = `<span class="badge staff">👤 ${u.name}</span>`;
    grid.appendChild(nameCell);
    for(let i=0;i<7;i++){
      const d = new Date(start); d.setDate(d.getDate()+i);
      const dateStr = Data.fmt(d);
      const cell = document.createElement('div'); cell.className='cell';
      const shift = Data.shifts.find(s=>s.date===dateStr && s.assigneeId===u.id);
      if(shift){
        const tmpl = Data.templates.find(t=>t.id===shift.templateId);
        const btns = [];
        if(state.role==='STAFF' && u.id===getCurrentUserId()){
          btns.push(`<button class="swap" data-shift="${shift.id}">Request swap</button>`);
        }
        cell.innerHTML = `
          <div><span class="badge assigned">Assigned</span></div>
          <div style="margin-top:6px">${tmpl.name} ${tmpl.start}–${tmpl.end}</div>
          <div style="margin-top:8px;display:flex;gap:6px">${btns.join('')}</div>
        `;
      } else {
        cell.innerHTML = `<span class="badge">Free</span>`;
      }
      grid.appendChild(cell);
    }
  });

  grid.addEventListener('click', e=>{
    if(e.target.matches('button.swap')){
      const shiftId = e.target.dataset.shift;
      openSwapDialog(shiftId);
    }
  }, { once:true });

  $('#scheduleLegend').textContent = state.role==='STAFF'
    ? 'Tip: click Request swap on one of your assigned days to propose a swap'
    : 'Manager view shows the roster for each staff this week';
}

function getCurrentUserId(){
  // pick first staff as current user for simulation
  return 'u1';
}

function openSwapDialog(shiftId){
  const shift = Data.shifts.find(s=>s.id===shiftId);
  const me = Data.users.find(u=>u.id===getCurrentUserId());
  const candidates = Data.users.filter(u=>u.role==='STAFF' && u.id!==me.id);
  const choice = prompt(`Swap ${shift.date} ${shiftId} with:\n${candidates.map(c=>c.name).join(', ')}`);
  if(!choice) return;
  const target = candidates.find(c=> choice.toLowerCase().includes(c.name.split(' ')[0].toLowerCase()));
  if(!target){ alert('No matching staff found'); return; }
  Data.swaps.push({ id: 'sw'+(Data.swaps.length+1), source: shiftId, initiator: me.id, target: target.id, status:'PROPOSED', createdAt: new Date().toISOString() });
  alert('Swap proposed and sent to manager');
}

// ----- Requests -----
function onLeaveSubmit(e){
  e.preventDefault();
  const fd = new FormData(e.target);
  const req = {
    id: 'lr'+(Data.leaveRequests.length+1),
    userId: getCurrentUserId(),
    type: fd.get('type'),
    start: fd.get('start'),
    end: fd.get('end'),
    comment: fd.get('comment') || '',
    status: 'PENDING',
    createdAt: new Date().toISOString()
  };
  Data.leaveRequests.push(req);
  e.target.reset();
  renderRequests();
  alert('Leave request submitted');
}

function renderRequests(){
  const mine = Data.leaveRequests.filter(r=>r.userId===getCurrentUserId());
  $('#myRequests').innerHTML = mine.map(r=>`
    <li>
      <div>
        <div><span class="badge ${r.status.toLowerCase()}">${r.status}</span></div>
        <div>${r.type} • ${r.start} → ${r.end}</div>
        <div class="hint">${r.comment || ''}</div>
      </div>
      <div class="hint">${new Date(r.createdAt).toLocaleString()}</div>
    </li>
  `).join('') || '<li class="hint">No requests yet</li>';

  if(state.role==='MANAGER'){
    $('#managerApprovals').classList.remove('hidden');
    const pending = Data.leaveRequests.filter(r=>r.status==='PENDING');
    $('#pendingApprovals').innerHTML = pending.map(r=>`
      <li>
        <div>
          <div><strong>${getUserName(r.userId)}</strong></div>
          <div>${r.type} • ${r.start} → ${r.end}</div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="approve" data-id="${r.id}">Approve</button>
          <button class="reject" data-id="${r.id}">Reject</button>
        </div>
      </li>
    `).join('') || '<li class="hint">No pending approvals</li>';

    $('#pendingApprovals').onclick = (ev)=>{
      const id = ev.target.dataset.id;
      if(!id) return;
      const item = Data.leaveRequests.find(x=>x.id===id);
      if(!item) return;
      item.status = ev.target.classList.contains('approve') ? 'APPROVED' : 'REJECTED';
      renderRequests();
    };
  } else {
    $('#managerApprovals').classList.add('hidden');
  }
}

function getUserName(id){
  return (Data.users.find(u=>u.id===id)||{}).name || id;
}

// ----- Templates -----
function renderTemplates(){
  const list = $('#templateList');
  list.innerHTML = Data.templates.map(t=>`
    <li><div>${t.name} • ${t.start}–${t.end} • ${t.role}</div></li>
  `).join('');
}

function onTemplateSubmit(e){
  e.preventDefault();
  const fd = new FormData(e.target);
  Data.templates.push({
    id: 't'+(Data.templates.length+1),
    name: fd.get('name'),
    role: fd.get('role'),
    start: fd.get('start'),
    end: fd.get('end')
  });
  e.target.reset();
  renderTemplates();
}

// ----- Timesheets -----
function onTimesheetGenerate(e){
  e.preventDefault();
  const fd = new FormData(e.target);
  const start = fd.get('start');
  const end = fd.get('end');
  const table = $('#timesheetTable');
  $('#tsTitle').textContent = `Results • ${start} → ${end}`;
  // naive calc: each shift = 8 hours
  const rows = Data.users.filter(u=>u.role==='STAFF').map(u=>{
    const worked = Data.shifts.filter(s=>s.assigneeId===u.id && s.date>=start && s.date<=end).length * 8;
    const overtime = Math.max(0, worked - 40);
    return { name: u.name, worked, overtime };
  });
  table.innerHTML = `
    <thead><tr><th>Staff</th><th>Hours</th><th>Overtime</th></tr></thead>
    <tbody>
      ${rows.map(r=>`<tr><td>${r.name}</td><td>${r.worked}</td><td>${r.overtime}</td></tr>`).join('')}
    </tbody>
  `;
}
